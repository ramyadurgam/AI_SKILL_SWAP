# AI SkillSwap — Simple Version

Just 4 things, kept minimal:
- **Python** — `backend.py`, standard library only (`http.server`), no Flask/Django needed
- **HTML** — page structure in `index.html`
- **CSS** — plain inline `<style>` block, no framework
- **React (basic)** — loaded via CDN in `index.html`, function components + `useState`/`useEffect` only, no extra libraries

## How to run

1. Start the backend:
   ```
   python3 backend.py
   ```
   Runs at http://localhost:8000

2. Open `index.html` in a browser (with the backend running).

3. Add a student (name, skill they teach, skill they want, availability),
   then click **Run matching** to see the AI-ranked results.

## Endpoints

| Method | Path      | Does |
|--------|-----------|------|
| GET    | /students | List students |
| POST   | /students | Add a student |
| GET    | /match    | Run matching, return ranked results |

Matching scores on: skill name similarity, teacher level vs. what's wanted,
shared availability, and a bonus if it's a mutual swap.
